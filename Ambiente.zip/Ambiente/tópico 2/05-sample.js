function calcularSalarioFuncionario(horasTrabalhadas, valorHora, cargo) {
    const salarioBase = horasTrabalhadas * valorHora;
    let bonusGerente = 1000;
    let bonusSupervisor = 500
    let bonusBasico = 200

    let salarioComBonus;
    if (cargo === 'gerente') {
        salarioComBonus = salarioBase + bonusGerente;
    } else if (cargo === 'supervisor') {
        salarioComBonus = salarioBase + bonusSupervisor;
    } else {
        salarioComBonus = salarioBase + bonusBasico;
    }

    const salarioComDesconto = salarioComBonus - 300;

    let descontoMaximo = 0.27;
    let descontoMedio = 0.18;
    let descontoBasico = 0.11;

    let salarioFinal;
    if (salarioComDesconto > 5000) {
        salarioFinal = salarioComDesconto - (salarioComDesconto * descontoMaximo);
    } else if (salarioComDesconto > 3000) {
        salarioFinal = salarioComDesconto - (salarioComDesconto * descontoMedio);
    } else {
        salarioFinal = salarioComDesconto - (salarioComDesconto * descontoBasico);
    }

    return salarioFinal;
}

const salario = calcularSalarioFuncionario(160, 25, 'gerente');
console.log(`O salário final é: ${salario}`);
