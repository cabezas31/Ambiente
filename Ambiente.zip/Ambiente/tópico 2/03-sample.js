function calcularFrete(distancia) {
    let fretePorKM = 50
    return distancia * fretePorKM;
}

const frete = calcularFrete(50);
console.log(`O valor do frete é: ${frete}`);
