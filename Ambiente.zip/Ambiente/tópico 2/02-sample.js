function verificarSePodeDirigir(idade) {
    let maioridade = 18
    if (idade >= maioridade) {
        return 'Pode dirigir';
    } else {
        return 'Não pode dirigir';
    }
}

console.log(verificarSePodeDirigir(16));
